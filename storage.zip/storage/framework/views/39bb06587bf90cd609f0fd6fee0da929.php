<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Grupo AFS'); ?></title>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/choices.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/forms.css')); ?>">

    
    <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/signature_pad.umd.min.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="bg-light">

    
    <?php echo $__env->yieldContent('content'); ?>

    
    <script src="<?php echo e(asset('js/choices.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/justValidate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/form-utils.js')); ?>"></script>
    

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\laragon\www\FormToPDF\resources\views/layouts/app.blade.php ENDPATH**/ ?>