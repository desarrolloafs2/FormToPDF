<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'name',
    'label' => '',
    'options' => [],
    'required' => false,
    'selected' => old($name),
    'class' => 'form-select',
    'placeholder' => 'Selecciona una opción',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'name',
    'label' => '',
    'options' => [],
    'required' => false,
    'selected' => old($name),
    'class' => 'form-select',
    'placeholder' => 'Selecciona una opción',
]); ?>
<?php foreach (array_filter(([
    'name',
    'label' => '',
    'options' => [],
    'required' => false,
    'selected' => old($name),
    'class' => 'form-select',
    'placeholder' => 'Selecciona una opción',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="mb-3">
    <?php if($label): ?>
        <label for="<?php echo e($name); ?>" class="form-label"><?php echo e($label); ?><?php if($required): ?><span class="text-danger"> *</span><?php endif; ?></label>
    <?php endif; ?>

    <select
        id="<?php echo e($name); ?>"
        name="<?php echo e($name); ?>"
        <?php echo e($required ? 'required' : ''); ?>

        <?php echo e($attributes->merge(['class' => $class])); ?>

    >
        <option value=""><?php echo e($placeholder); ?></option>
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php if($selected == $value): echo 'selected'; endif; ?>>
                <?php echo e($text); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<?php /**PATH C:\laragon\www\FormToPDF\resources\views/components/select.blade.php ENDPATH**/ ?>